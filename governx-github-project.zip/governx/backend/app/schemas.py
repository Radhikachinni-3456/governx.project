from datetime import datetime
from typing import Literal
from pydantic import BaseModel, ConfigDict, Field

ResultStatus = Literal["not_assessed", "not_implemented", "partially_implemented", "implemented", "not_applicable"]
TaskStatus = Literal["open", "in_progress", "blocked", "done"]

class OutcomeOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: str
    function: str
    category: str
    title: str
    description: str
    source_note: str

class AssessmentCreate(BaseModel):
    name: str = Field(min_length=1, max_length=200)
    organization: str = Field(min_length=1, max_length=200)
    scope: str = ""
    assessor: str = ""

class AssessmentOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    name: str
    organization: str
    scope: str
    assessor: str
    created_at: datetime

class ResultUpsert(BaseModel):
    status: ResultStatus
    evidence_notes: str = ""
    rationale: str = ""
    likelihood: int = Field(default=1, ge=1, le=5)
    impact: int = Field(default=1, ge=1, le=5)

class ResultOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    assessment_id: int
    outcome_id: str
    status: str
    evidence_notes: str
    rationale: str
    likelihood: int
    impact: int
    updated_at: datetime

class TaskCreate(BaseModel):
    assessment_id: int
    outcome_id: str
    title: str = Field(min_length=1, max_length=240)
    description: str = ""
    owner: str = ""
    due_date: str = ""

class TaskUpdate(BaseModel):
    status: TaskStatus

class TaskOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    assessment_id: int
    outcome_id: str
    title: str
    description: str
    owner: str
    due_date: str
    status: str
    created_at: datetime
