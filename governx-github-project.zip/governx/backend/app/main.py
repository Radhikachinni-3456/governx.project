from contextlib import asynccontextmanager
from fastapi import Depends, FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy import select
from sqlalchemy.orm import Session, joinedload
from .database import Base, engine, get_db
from .models import Assessment, AssessmentResult, FrameworkOutcome, RemediationTask
from .schemas import (
    AssessmentCreate, AssessmentOut, OutcomeOut, ResultOut, ResultUpsert,
    TaskCreate, TaskOut, TaskUpdate
)

# These are illustrative records for a runnable demo, not a complete official NIST catalog.
STARTER_OUTCOMES = [
    ("GV.OC-01","Govern","Organizational Context","The organizational mission is understood and informs cybersecurity risk management.",""),
    ("GV.RR-02","Govern","Roles, Responsibilities, and Authorities","Cybersecurity roles and responsibilities are established and communicated.",""),
    ("GV.PO-01","Govern","Policy","Cybersecurity risk management policy is established based on organizational context and strategy.",""),
    ("GV.OV-01","Govern","Oversight","Cybersecurity risk management strategy outcomes are reviewed to inform and adjust strategy and direction.",""),
    ("ID.AM-01","Identify","Asset Management","Inventories of hardware managed by the organization are maintained.",""),
    ("ID.RA-01","Identify","Risk Assessment","Vulnerabilities in assets are identified, validated, and recorded.",""),
    ("ID.RA-05","Identify","Risk Assessment","Threats, vulnerabilities, likelihoods, and impacts are used to understand inherent risk.",""),
    ("PR.AA-01","Protect","Identity Management, Authentication, and Access Control","Identities and credentials for authorized users, services, and hardware are managed.",""),
    ("PR.AT-01","Protect","Awareness and Training","Personnel are provided with awareness and training so they can perform cybersecurity duties.",""),
    ("PR.DS-01","Protect","Data Security","The confidentiality, integrity, and availability of data-at-rest are protected.",""),
    ("DE.CM-01","Detect","Continuous Monitoring","Networks and network services are monitored to find potentially adverse events.",""),
    ("DE.AE-02","Detect","Adverse Event Analysis","Potentially adverse events are analyzed to better understand associated activities.",""),
    ("RS.MA-01","Respond","Incident Management","The incident response plan is executed in coordination with relevant third parties once an incident is declared.",""),
    ("RS.CO-02","Respond","Incident Response Reporting and Communication","Internal and external stakeholders are notified of incidents as required by plans.",""),
    ("RC.RP-01","Recover","Incident Recovery Plan Execution","The recovery portion of the incident response plan is executed once initiated.",""),
    ("RC.CO-03","Recover","Incident Recovery Communication","Recovery activities and progress in restoring operational capabilities are communicated to designated stakeholders.",""),
]
FUNCTIONS = ["Govern", "Identify", "Protect", "Detect", "Respond", "Recover"]

def seed_framework(db: Session):
    existing = db.scalar(select(FrameworkOutcome.id).limit(1))
    if existing:
        return
    for oid, fn, category, title, desc in STARTER_OUTCOMES:
        db.add(FrameworkOutcome(
            id=oid, function=fn, category=category, title=title,
            description=desc,
            source_note="Illustrative starter record; verify exact wording and identifiers against official NIST CSF 2.0 reference data"
        ))
    db.commit()

@asynccontextmanager
async def lifespan(app: FastAPI):
    Base.metadata.create_all(bind=engine)
    with next(get_db()) as db:
        seed_framework(db)
    yield

app = FastAPI(
    title="GovernX API",
    description="Starter API for NIST CSF 2.0 outcome assessments, evidence notes, risk triage, and remediation.",
    version="0.1.0",
    lifespan=lifespan,
)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://127.0.0.1:5173"],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/health")
def health():
    return {"status": "ok", "service": "governx-api"}

@app.get("/api/framework", response_model=list[OutcomeOut])
def list_framework(function: str | None = Query(default=None), db: Session = Depends(get_db)):
    stmt = select(FrameworkOutcome).order_by(FrameworkOutcome.function, FrameworkOutcome.id)
    if function:
        stmt = stmt.where(FrameworkOutcome.function.ilike(function))
    return list(db.scalars(stmt))

@app.post("/api/assessments", response_model=AssessmentOut, status_code=201)
def create_assessment(payload: AssessmentCreate, db: Session = Depends(get_db)):
    assessment = Assessment(**payload.model_dump())
    db.add(assessment)
    db.flush()
    for outcome in db.scalars(select(FrameworkOutcome)):
        db.add(AssessmentResult(assessment_id=assessment.id, outcome_id=outcome.id))
    db.commit()
    db.refresh(assessment)
    return assessment

@app.get("/api/assessments", response_model=list[AssessmentOut])
def list_assessments(db: Session = Depends(get_db)):
    return list(db.scalars(select(Assessment).order_by(Assessment.created_at.desc())))

@app.get("/api/assessments/{assessment_id}")
def get_assessment(assessment_id: int, db: Session = Depends(get_db)):
    assessment = db.get(Assessment, assessment_id)
    if not assessment:
        raise HTTPException(404, "Assessment not found")
    results = db.scalars(
        select(AssessmentResult)
        .options(joinedload(AssessmentResult.outcome))
        .where(AssessmentResult.assessment_id == assessment_id)
        .order_by(AssessmentResult.outcome_id)
    ).unique().all()
    return {
        "assessment": AssessmentOut.model_validate(assessment),
        "results": [
            {**ResultOut.model_validate(r).model_dump(mode="json"),
             "outcome": OutcomeOut.model_validate(r.outcome).model_dump()}
            for r in results
        ],
    }

@app.put("/api/assessments/{assessment_id}/results/{outcome_id}", response_model=ResultOut)
def upsert_result(assessment_id: int, outcome_id: str, payload: ResultUpsert, db: Session = Depends(get_db)):
    if not db.get(Assessment, assessment_id):
        raise HTTPException(404, "Assessment not found")
    if not db.get(FrameworkOutcome, outcome_id):
        raise HTTPException(404, "Framework outcome not found")
    result = db.scalar(select(AssessmentResult).where(
        AssessmentResult.assessment_id == assessment_id,
        AssessmentResult.outcome_id == outcome_id
    ))
    if result is None:
        result = AssessmentResult(assessment_id=assessment_id, outcome_id=outcome_id)
        db.add(result)
    for key, value in payload.model_dump().items():
        setattr(result, key, value)
    db.commit()
    db.refresh(result)
    return result

@app.get("/api/assessments/{assessment_id}/summary")
def assessment_summary(assessment_id: int, db: Session = Depends(get_db)):
    if not db.get(Assessment, assessment_id):
        raise HTTPException(404, "Assessment not found")
    results = list(db.scalars(select(AssessmentResult).where(AssessmentResult.assessment_id == assessment_id)))
    applicable = [r for r in results if r.status not in ("not_assessed", "not_applicable")]
    implemented = sum(r.status == "implemented" for r in applicable)
    gaps = [r for r in applicable if r.status in ("not_implemented", "partially_implemented")]
    assessed_count = len(applicable)
    coverage = round(implemented / assessed_count * 100, 1) if assessed_count else 0.0
    return {
        "assessment_id": assessment_id,
        "total_outcomes": len(results),
        "assessed_applicable": assessed_count,
        "implemented": implemented,
        "open_gaps": len(gaps),
        "coverage_percent": coverage,
        "high_priority_gaps": sum((r.likelihood * r.impact) >= 15 for r in gaps),
        "metric_note": "Project-defined indicator, not a NIST-defined compliance score.",
    }

@app.post("/api/tasks", response_model=TaskOut, status_code=201)
def create_task(payload: TaskCreate, db: Session = Depends(get_db)):
    if not db.get(Assessment, payload.assessment_id):
        raise HTTPException(404, "Assessment not found")
    if not db.get(FrameworkOutcome, payload.outcome_id):
        raise HTTPException(404, "Framework outcome not found")
    task = RemediationTask(**payload.model_dump())
    db.add(task)
    db.commit()
    db.refresh(task)
    return task

@app.get("/api/tasks", response_model=list[TaskOut])
def list_tasks(assessment_id: int | None = None, db: Session = Depends(get_db)):
    stmt = select(RemediationTask).order_by(RemediationTask.created_at.desc())
    if assessment_id is not None:
        stmt = stmt.where(RemediationTask.assessment_id == assessment_id)
    return list(db.scalars(stmt))

@app.patch("/api/tasks/{task_id}", response_model=TaskOut)
def update_task(task_id: int, payload: TaskUpdate, db: Session = Depends(get_db)):
    task = db.get(RemediationTask, task_id)
    if not task:
        raise HTTPException(404, "Task not found")
    task.status = payload.status
    db.commit()
    db.refresh(task)
    return task
