import os
import tempfile

# Set a per-test database before importing the app.
_db_file = tempfile.NamedTemporaryFile(suffix=".db", delete=False)
_db_file.close()
os.environ["DATABASE_URL"] = f"sqlite:///{_db_file.name}"

from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)
client.__enter__()  # Start FastAPI lifespan so tables and starter outcomes are initialized.

def test_health():
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json()["status"] == "ok"

def test_framework_seeded():
    response = client.get("/api/framework")
    assert response.status_code == 200
    data = response.json()
    assert len(data) >= 6
    assert {item["function"] for item in data} == {"Govern", "Identify", "Protect", "Detect", "Respond", "Recover"}

def test_assessment_result_and_summary():
    created = client.post("/api/assessments", json={
        "name": "Demo assessment", "organization": "Example Org",
        "scope": "Corporate IT", "assessor": "Demo User"
    })
    assert created.status_code == 201
    assessment_id = created.json()["id"]
    result = client.put(f"/api/assessments/{assessment_id}/results/GV.OC-01", json={
        "status": "implemented", "evidence_notes": "Policy review completed",
        "rationale": "Evidence reviewed", "likelihood": 2, "impact": 3
    })
    assert result.status_code == 200
    summary = client.get(f"/api/assessments/{assessment_id}/summary").json()
    assert summary["implemented"] == 1
    assert summary["coverage_percent"] == 100.0

def test_missing_assessment():
    response = client.get("/api/assessments/999999/summary")
    assert response.status_code == 404
