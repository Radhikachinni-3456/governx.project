# Security notes

This repository is a learning/demo starter, not a production-hardened GRC platform.

## Before deployment

- Implement authentication and authorization. The current demo API has no login or access control.
- Restrict CORS to your deployed frontend origin.
- Do not expose the API publicly until access control and tenant isolation are implemented.
- Never commit secrets, customer evidence, exports, logs, or database files.
- Use HTTPS, secure secret storage, backups, dependency scanning, and patch management.
- Validate and sanitize evidence uploads if file upload support is added.
- Define retention, privacy, incident response, and access review processes.
- Run a security review and threat model before handling real assessments.

## Responsible use

Framework mappings and sample outcomes are illustrative. Validate identifiers and exact outcome language against the official NIST CSF 2.0 references. Do not represent application-generated metrics as official NIST certification or a guarantee of compliance.
