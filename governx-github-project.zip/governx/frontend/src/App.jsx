import { useEffect, useMemo, useState } from 'react'
import { ShieldCheck, LayoutDashboard, ClipboardCheck, ListTodo, Settings, Search, Bell, Plus, ArrowUpRight, ShieldAlert, CheckCircle2, Clock3, CircleHelp, RefreshCw } from 'lucide-react'

const API = import.meta.env.VITE_API_URL || 'http://localhost:8000'
const functions = ['All functions', 'Govern', 'Identify', 'Protect', 'Detect', 'Respond', 'Recover']
const statusLabels = {
  not_assessed: 'Not assessed',
  not_implemented: 'Not implemented',
  partially_implemented: 'Partial',
  implemented: 'Implemented',
  not_applicable: 'Not applicable'
}
const statusClass = {
  not_assessed: 'muted', not_implemented: 'danger',
  partially_implemented: 'warning', implemented: 'success', not_applicable: 'muted'
}

export default function App() {
  const [framework, setFramework] = useState([])
  const [assessments, setAssessments] = useState([])
  const [tasks, setTasks] = useState([])
  const [selected, setSelected] = useState('')
  const [summary, setSummary] = useState(null)
  const [results, setResults] = useState([])
  const [activeTab, setActiveTab] = useState('Overview')
  const [filter, setFilter] = useState('All functions')
  const [search, setSearch] = useState('')
  const [showCreate, setShowCreate] = useState(false)
  const [notice, setNotice] = useState('')
  const [loading, setLoading] = useState(true)

  async function request(path, options = {}) {
    const res = await fetch(`${API}${path}`, {
      headers: { 'Content-Type': 'application/json', ...(options.headers || {}) },
      ...options
    })
    if (!res.ok) {
      const body = await res.json().catch(() => ({}))
      throw new Error(body.detail || `Request failed (${res.status})`)
    }
    if (res.status === 204) return null
    return res.json()
  }
  async function loadBase() {
    setLoading(true)
    try {
      const [f, a, t] = await Promise.all([
        request('/api/framework'), request('/api/assessments'), request('/api/tasks')
      ])
      setFramework(f); setAssessments(a); setTasks(t)
      if (a.length && !selected) setSelected(String(a[0].id))
      setNotice('')
    } catch (e) {
      setNotice(`Could not connect to API: ${e.message}. Start the backend and refresh.`)
    } finally { setLoading(false) }
  }
  async function loadAssessment(id) {
    if (!id) { setSummary(null); setResults([]); return }
    try {
      const [s, detail] = await Promise.all([
        request(`/api/assessments/${id}/summary`), request(`/api/assessments/${id}`)
      ])
      setSummary(s); setResults(detail.results || [])
    } catch (e) { setNotice(e.message) }
  }
  useEffect(() => { loadBase() }, [])
  useEffect(() => { loadAssessment(selected) }, [selected])
  const filtered = useMemo(() => framework.filter(o =>
    (filter === 'All functions' || o.function === filter) &&
    `${o.id} ${o.title} ${o.category}`.toLowerCase().includes(search.toLowerCase())
  ), [framework, filter, search])
  const resultByOutcome = useMemo(() => Object.fromEntries(results.map(r => [r.outcome_id, r])), [results])

  async function createAssessment(e) {
    e.preventDefault()
    const form = new FormData(e.currentTarget)
    try {
      const a = await request('/api/assessments', { method: 'POST', body: JSON.stringify({
        name: form.get('name'), organization: form.get('organization'),
        scope: form.get('scope'), assessor: form.get('assessor')
      }) })
      setAssessments(old => [a, ...old]); setSelected(String(a.id)); setShowCreate(false); setActiveTab('Assessments')
      setNotice('Assessment created successfully.')
    } catch (err) { setNotice(err.message) }
  }
  async function saveStatus(outcome, status) {
    if (!selected) { setNotice('Create an assessment before recording results.'); return }
    const current = resultByOutcome[outcome.id] || {}
    try {
      await request(`/api/assessments/${selected}/results/${encodeURIComponent(outcome.id)}`, {
        method: 'PUT', body: JSON.stringify({
          status, evidence_notes: current.evidence_notes || '', rationale: current.rationale || '',
          likelihood: current.likelihood || 1, impact: current.impact || 1
        })
      })
      await loadAssessment(selected)
      setNotice(`Saved ${outcome.id}.`)
    } catch (err) { setNotice(err.message) }
  }
  async function createTask(e) {
    e.preventDefault()
    const form = new FormData(e.currentTarget)
    try {
      await request('/api/tasks', { method: 'POST', body: JSON.stringify({
        assessment_id: Number(selected), outcome_id: form.get('outcome_id'),
        title: form.get('title'), owner: form.get('owner'), due_date: form.get('due_date'),
        description: form.get('description')
      }) })
      setTasks(await request('/api/tasks')); e.currentTarget.reset()
      setNotice('Remediation task created.')
    } catch (err) { setNotice(err.message) }
  }
  async function updateTask(id, status) {
    try {
      await request(`/api/tasks/${id}`, { method: 'PATCH', body: JSON.stringify({ status }) })
      setTasks(await request('/api/tasks'))
    } catch (err) { setNotice(err.message) }
  }
  const activeAssessment = assessments.find(a => String(a.id) === selected)
  const assessed = summary?.assessed_applicable || 0
  const coverage = summary?.coverage_percent || 0
  const progressWidth = `${Math.min(100, Math.max(0, coverage))}%`

  return <div className="app-shell">
    <aside className="sidebar">
      <div className="brand"><div className="brand-mark"><ShieldCheck size={22}/></div><div><b>Govern<span>X</span></b><small>SECURITY GOVERNANCE</small></div></div>
      <div className="workspace-label">WORKSPACE</div>
      <nav>
        {[
          ['Overview', LayoutDashboard], ['Assessments', ClipboardCheck],
          ['Remediation', ListTodo], ['Framework library', ShieldCheck]
        ].map(([label, Icon]) => <button key={label} className={`nav-item ${activeTab === label ? 'active' : ''}`} onClick={() => setActiveTab(label)}><Icon size={18}/><span>{label}</span>{label === 'Remediation' && tasks.some(t => t.status !== 'done') && <i className="nav-count">{tasks.filter(t => t.status !== 'done').length}</i>}</button>)}
      </nav>
      <div className="sidebar-bottom">
        <div className="help-card"><div className="help-icon"><CircleHelp size={18}/></div><b>Need a hand?</b><p>Review the setup guide and API documentation.</p><a href={`${API}/docs`} target="_blank" rel="noreferrer">Open API docs <ArrowUpRight size={13}/></a></div>
        <button className="nav-item" onClick={() => setNotice('Demo settings: configure VITE_API_URL in frontend environment.') }><Settings size={18}/><span>Settings</span></button>
        <div className="profile"><div className="avatar">GX</div><div><b>GovernX Demo</b><small>Workspace admin</small></div><span className="profile-dots">•••</span></div>
      </div>
    </aside>

    <main className="main">
      <header className="topbar">
        <div className="breadcrumbs">Workspace <span>/</span> <b>{activeTab}</b></div>
        <div className="top-actions"><span className="environment"><i/> Demo environment</span><button className="icon-button" aria-label="Refresh" onClick={loadBase}><RefreshCw size={17}/></button><button className="icon-button" aria-label="Notifications" onClick={() => setNotice('You are all caught up.') }><Bell size={17}/></button><div className="avatar small-avatar">GX</div></div>
      </header>
      <div className="content">
        <div className="page-heading">
          <div><div className="eyebrow">CYBERSECURITY POSTURE</div><h1>{activeTab === 'Overview' ? 'Governance overview' : activeTab}</h1><p>Assess, track, and strengthen your security posture against NIST CSF 2.0.</p></div>
          <div className="heading-actions"><button className="button secondary" onClick={loadBase}><RefreshCw size={15}/> Refresh</button><button className="button primary" onClick={() => setShowCreate(true)}><Plus size={16}/> New assessment</button></div>
        </div>
        {notice && <div className="notice" role="status"><span>{notice}</span><button onClick={() => setNotice('')} aria-label="Dismiss">×</button></div>}
        {loading && <div className="loading">Loading GovernX workspace…</div>}

        {activeTab === 'Overview' && <>
          <div className="context-bar"><div className="context-left"><span className="context-icon"><ClipboardCheck size={17}/></span><div><small>ACTIVE ASSESSMENT</small><b>{activeAssessment?.name || 'No assessment selected'}</b></div></div><select aria-label="Select assessment" value={selected} onChange={e => setSelected(e.target.value)}><option value="">Select assessment</option>{assessments.map(a => <option key={a.id} value={a.id}>{a.name} — {a.organization}</option>)}</select></div>
          <div className="metrics-grid">
            <Metric label="Implementation coverage" value={`${coverage}%`} change="Project-defined indicator" icon={<ShieldCheck size={18}/>} tone="blue" />
            <Metric label="Open gaps" value={summary?.open_gaps ?? '—'} change="Not or partially implemented" icon={<ShieldAlert size={18}/>} tone="orange" />
            <Metric label="High-priority gaps" value={summary?.high_priority_gaps ?? '—'} change="Risk score ≥ 15 / 25" icon={<Bell size={18}/>} tone="red" />
            <Metric label="Remediation tasks" value={tasks.filter(t => t.status !== 'done').length} change={`${tasks.filter(t => t.status === 'done').length} completed`} icon={<CheckCircle2 size={18}/>} tone="green" />
          </div>
          <div className="dashboard-grid">
            <section className="panel coverage-panel">
              <div className="panel-heading"><div><h2>Framework coverage</h2><p>Outcome assessment status across the six CSF functions</p></div><span className="pill">NIST CSF 2.0</span></div>
              <div className="coverage-hero"><div className="donut" style={{'--coverage': `${coverage * 3.6}deg`}}><div><strong>{coverage}%</strong><small>coverage</small></div></div><div className="coverage-copy"><h3>{coverage >= 80 ? 'Strong progress' : coverage > 0 ? 'Room to improve' : 'Assessment not started'}</h3><p>{summary ? `${summary.implemented} implemented of ${assessed} assessed applicable outcomes.` : 'Create an assessment to start evaluating framework outcomes.'}</p><div className="legend"><span><i className="dot green-dot"/>Implemented</span><span><i className="dot orange-dot"/>Open gaps</span><span><i className="dot gray-dot"/>Not assessed</span></div></div></div>
              <div className="progress-caption"><span>Assessed outcomes</span><b>{assessed} / {summary?.total_outcomes ?? framework.length}</b></div><div className="progress-track"><div style={{width: `${summary?.total_outcomes ? assessed / summary.total_outcomes * 100 : 0}%`}}/></div>
              <div className="function-list">{['Govern','Identify','Protect','Detect','Respond','Recover'].map((fn, i) => {
                const items = results.filter(r => r.outcome?.function === fn)
                const done = items.filter(r => r.status === 'implemented').length
                const denominator = items.filter(r => !['not_assessed','not_applicable'].includes(r.status)).length
                const pct = denominator ? Math.round(done / denominator * 100) : 0
                return <div className="function-row" key={fn}><div className={`function-icon f${i}`}>{fn.slice(0,1)}</div><span>{fn}</span><div className="mini-track"><div style={{width:`${pct}%`}}/></div><b>{pct}%</b></div>
              })}</div>
            </section>
            <section className="panel action-panel">
              <div className="panel-heading"><div><h2>Priority actions</h2><p>Suggested next steps from assessment gaps</p></div><button className="text-button" onClick={() => setActiveTab('Framework library')}>View outcomes <ArrowUpRight size={14}/></button></div>
              <div className="action-list">
                {results.filter(r => ['not_implemented','partially_implemented'].includes(r.status)).sort((a,b) => b.likelihood*b.impact - a.likelihood*a.impact).slice(0,4).map(r => <div className="action-item" key={r.outcome_id}><div className="action-symbol"><ShieldAlert size={17}/></div><div className="action-info"><b>{r.outcome?.title || r.outcome_id}</b><p>{r.outcome_id} · {r.outcome?.function}</p></div><span className={`risk-tag ${(r.likelihood*r.impact)>=15?'high':'medium'}`}>{(r.likelihood*r.impact)>=15?'High':'Review'}</span></div>)}
                {!results.some(r => ['not_implemented','partially_implemented'].includes(r.status)) && <div className="empty-state"><CheckCircle2 size={26}/><b>No recorded gaps yet</b><p>Assess outcomes in the Framework library to surface priority actions.</p></div>}
              </div>
              <div className="panel-footer"><span><Clock3 size={14}/> Review gaps regularly</span><button className="button secondary small" onClick={() => setActiveTab('Framework library')}>Review assessment</button></div>
            </section>
          </div>
          <section className="panel outcomes-panel">
            <div className="panel-heading"><div><h2>Outcome assessment</h2><p>Update implementation status for your active assessment</p></div><button className="text-button" onClick={() => setActiveTab('Framework library')}>Open framework library <ArrowUpRight size={14}/></button></div>
            <OutcomeTable outcomes={filtered.slice(0,5)} resultByOutcome={resultByOutcome} onSave={saveStatus} />
          </section>
        </>}

        {activeTab === 'Assessments' && <section className="panel full-panel"><div className="panel-heading"><div><h2>Assessments</h2><p>Assessment scope and ownership</p></div><button className="button primary" onClick={() => setShowCreate(true)}><Plus size={15}/> New assessment</button></div>{assessments.length ? <div className="table-wrap"><table><thead><tr><th>Name</th><th>Organization</th><th>Assessor</th><th>Created</th><th></th></tr></thead><tbody>{assessments.map(a=><tr key={a.id}><td><b>{a.name}</b><small className="cell-sub">{a.scope || 'Scope not specified'}</small></td><td>{a.organization}</td><td>{a.assessor || '—'}</td><td>{new Date(a.created_at).toLocaleDateString()}</td><td><button className="text-button" onClick={() => {setSelected(String(a.id));setActiveTab('Overview')}}>Open <ArrowUpRight size={14}/></button></td></tr>)}</tbody></table></div>:<Empty title="No assessments yet" text="Create an assessment to start tracking CSF outcomes." />}</section>}

        {activeTab === 'Framework library' && <section className="panel full-panel"><div className="panel-heading"><div><h2>Framework outcome library</h2><p>Starter records across all six NIST CSF 2.0 functions</p></div><span className="pill">{framework.length} outcomes</span></div><div className="filters"><div className="search-field"><Search size={16}/><input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search outcomes, IDs, categories…"/></div><select value={filter} onChange={e=>setFilter(e.target.value)}>{functions.map(f=><option key={f}>{f}</option>)}</select></div><OutcomeTable outcomes={filtered} resultByOutcome={resultByOutcome} onSave={saveStatus} /></section>}

        {activeTab === 'Remediation' && <section className="panel full-panel"><div className="panel-heading"><div><h2>Remediation tracker</h2><p>Assign owners and track action status</p></div></div>{selected && <form className="task-form" onSubmit={createTask}><input name="title" placeholder="Action title" required/><select name="outcome_id" required defaultValue=""><option value="" disabled>Linked outcome</option>{framework.map(o=><option key={o.id} value={o.id}>{o.id} — {o.title}</option>)}</select><input name="owner" placeholder="Owner"/><input name="due_date" type="date" aria-label="Due date"/><input name="description" placeholder="Description (optional)"/><button className="button primary" type="submit"><Plus size={15}/> Add task</button></form>}{tasks.length ? <div className="table-wrap"><table><thead><tr><th>Task</th><th>Outcome</th><th>Owner</th><th>Due date</th><th>Status</th></tr></thead><tbody>{tasks.map(t=><tr key={t.id}><td><b>{t.title}</b><small className="cell-sub">{t.description}</small></td><td><code>{t.outcome_id}</code></td><td>{t.owner || 'Unassigned'}</td><td>{t.due_date || '—'}</td><td><select className={`task-status ${t.status}`} value={t.status} onChange={e=>updateTask(t.id,e.target.value)}><option value="open">Open</option><option value="in_progress">In progress</option><option value="blocked">Blocked</option><option value="done">Done</option></select></td></tr>)}</tbody></table></div>:<Empty title="No remediation tasks" text="Create tasks to track corrective actions for identified gaps."/>}</section>}
        <footer className="footer"><span>GovernX <b>v0.1.0</b></span><span>Assessment aid · Not an official NIST certification</span><a href="https://www.nist.gov/cyberframework" target="_blank" rel="noreferrer">NIST CSF reference <ArrowUpRight size={12}/></a></footer>
      </div>
    </main>

    {showCreate && <div className="modal-backdrop" onMouseDown={e=>{if(e.target===e.currentTarget)setShowCreate(false)}}><div className="modal"><div className="modal-title"><div><h2>Create assessment</h2><p>Define the organization and scope for this review.</p></div><button className="icon-button" onClick={()=>setShowCreate(false)}>×</button></div><form onSubmit={createAssessment} className="create-form"><label>Assessment name<input name="name" required placeholder="e.g. Annual security baseline"/></label><label>Organization<input name="organization" required placeholder="e.g. Example Corporation"/></label><label>Assessment scope<textarea name="scope" rows="3" placeholder="Systems, business units, locations…"/></label><label>Assessor<input name="assessor" placeholder="Name or team"/></label><div className="modal-actions"><button type="button" className="button secondary" onClick={()=>setShowCreate(false)}>Cancel</button><button type="submit" className="button primary"><Plus size={15}/> Create assessment</button></div></form></div></div>}
  </div>
}

function Metric({label,value,change,icon,tone}) {
  return <div className="metric-card"><div className={`metric-icon ${tone}`}>{icon}</div><div className="metric-label">{label}</div><div className="metric-value">{value}</div><div className="metric-change">{change}</div></div>
}
function OutcomeTable({outcomes,resultByOutcome,onSave}) {
  if (!outcomes.length) return <Empty title="No matching outcomes" text="Try another search or function filter."/>
  return <div className="table-wrap"><table><thead><tr><th>Outcome</th><th>Function</th><th>Status</th><th>Evidence</th></tr></thead><tbody>{outcomes.map(o=>{const r=resultByOutcome[o.id];return <tr key={o.id}><td><div className="outcome-cell"><code>{o.id}</code><b>{o.title}</b><small>{o.category}</small></div></td><td><span className="function-label">{o.function}</span></td><td><select aria-label={`Status for ${o.id}`} className={`status-select ${statusClass[r?.status || 'not_assessed']}`} value={r?.status || 'not_assessed'} onChange={e=>onSave(o,e.target.value)}><option value="not_assessed">Not assessed</option><option value="not_implemented">Not implemented</option><option value="partially_implemented">Partially implemented</option><option value="implemented">Implemented</option><option value="not_applicable">Not applicable</option></select></td><td><span className={`evidence-indicator ${r?.evidence_notes?'has-evidence':''}`}><i/>{r?.evidence_notes?'Evidence recorded':'No evidence notes'}</span></td></tr>})}</tbody></table></div>
}
function Empty({title,text}) { return <div className="empty-state large"><ClipboardCheck size={28}/><b>{title}</b><p>{text}</p></div> }
